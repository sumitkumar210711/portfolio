#include <stdio.h>

void main(){

    printf("sumit");
    return 0;
}