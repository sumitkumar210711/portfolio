import logo from './logo.svg';
import './App.css';
import Portfolio from './Pages/Portfolio';

function App() {
  return (
    <>
    
    <Portfolio />
    
    </>
  );
}

export default App;
